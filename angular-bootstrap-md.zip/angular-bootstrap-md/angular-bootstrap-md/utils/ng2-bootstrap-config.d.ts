export declare function isBs3(): boolean;

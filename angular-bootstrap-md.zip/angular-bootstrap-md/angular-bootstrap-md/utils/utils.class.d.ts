export declare class Utils {
    static reflow(element: any): void;
    static getStyles(elem: any): any;
}

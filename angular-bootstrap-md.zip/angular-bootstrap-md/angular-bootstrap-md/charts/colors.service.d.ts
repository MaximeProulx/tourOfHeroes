import { Color } from './color.service';
export interface Colors extends Color {
    data?: number[];
    label?: string;
}

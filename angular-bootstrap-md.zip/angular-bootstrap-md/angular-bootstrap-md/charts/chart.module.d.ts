export declare class ChartsModule {
}

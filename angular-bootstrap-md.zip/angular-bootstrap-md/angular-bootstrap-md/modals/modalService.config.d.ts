export declare const msConfig: {
    serviceInstance: Object;
};

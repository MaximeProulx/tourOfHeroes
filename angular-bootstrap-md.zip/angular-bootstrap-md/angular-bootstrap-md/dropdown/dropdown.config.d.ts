/** Default dropdown configuration */
export declare class BsDropdownConfig {
    /** default dropdown auto closing behavior */
    autoClose: boolean;
}

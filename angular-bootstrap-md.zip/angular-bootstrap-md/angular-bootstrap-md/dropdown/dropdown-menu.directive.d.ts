import { TemplateRef, ViewContainerRef } from '@angular/core';
import { BsDropdownState } from './dropdown.state';
export declare class BsDropdownMenuDirective {
    constructor(_state: BsDropdownState, _viewContainer: ViewContainerRef, _templateRef: TemplateRef<any>);
}
